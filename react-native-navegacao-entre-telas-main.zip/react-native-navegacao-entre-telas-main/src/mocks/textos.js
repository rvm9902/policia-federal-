const textos = {
    boasVindas: "Olá Natalia",
    legenda: "Encontre os produtores mais próximos a você!",
    legendaMelhoresProdutores: "Veja os produtores com 4+ estrelas!",
    tituloProdutores: "Produtores",
    tituloProdutor: "Detalhe do produtor",
    tituloCestas: "Cestas",
    topoCesta: "Detalhe da cesta",
    botaoComprar: "Comprar",
    tituloItens: "Itens da cesta",
};

export default textos;
